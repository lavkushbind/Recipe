package com.example.newrecipe.Model

data class User(
    val name: String,
    val userId: String,
    val email: String,
    val password: String,
    val profilePic:String,
    val Uid:String,
    val Save:String


)