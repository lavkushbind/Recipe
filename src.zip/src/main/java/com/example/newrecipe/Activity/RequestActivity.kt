package com.example.newrecipe.Activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.newrecipe.R

class RequestActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_request)
    }
}