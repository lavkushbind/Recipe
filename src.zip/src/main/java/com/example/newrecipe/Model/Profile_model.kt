package com.example.newrecipe.Model
data class profile_model (
    var username: String = "",
    var email: String = "",
    var imageUrl: String = ""

)